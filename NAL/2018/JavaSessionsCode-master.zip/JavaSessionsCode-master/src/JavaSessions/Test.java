package JavaSessions;

public class Test {

	public static void main(String[] args) {

		FunctionsInJava obj = new FunctionsInJava();
		
	}

	
		
	
}
