package OOP_2;

public interface UKBank {
	
	public void atmCard();
	
	public void trading();
	

}
