package OOP_2;

public interface USBank {
	
	int min_bal = 100;

	public void credit();
	
	public void debit();
	
	public void transferMoney();
	
	//public void crypto();
	
	//1. can not have method body -- only prototype/declaration
	//2. interface vars are static in nature by default
	//3. no static methods are allowed
	//4. can not create the object of interface
	
	
	
	
	
	
	
}
