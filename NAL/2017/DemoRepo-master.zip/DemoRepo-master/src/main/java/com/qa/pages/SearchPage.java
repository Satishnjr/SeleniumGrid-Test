package com.qa.pages;

public class SearchPage {
	
	
	
	public void searchPage(){
		System.out.println("searchPage");
	}

}
