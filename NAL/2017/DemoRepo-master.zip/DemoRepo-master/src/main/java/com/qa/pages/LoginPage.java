package com.qa.pages;

public class LoginPage {
	
	
	
	public void loginPage(){
		System.out.println("login page");
	}
	
	
	public void loginSet(){
		System.out.println("login set");
	} 
	

}
