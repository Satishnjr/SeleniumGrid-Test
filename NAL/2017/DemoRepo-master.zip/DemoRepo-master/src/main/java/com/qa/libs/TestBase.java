package com.qa.libs;

public class TestBase {
	
	
	public void test(){
		System.out.println("test method");
	}
	
	
	
	
	

}
