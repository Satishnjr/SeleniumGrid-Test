package com.qa.util;

public class TestUtil {
	
	
	public void testUtil(){
		System.out.println("test util");
	}
	
	

}
