package com.qa.pages;

public class HomePage {
	
	
	public void homePage(){
		System.out.println("home page");
	}
	
	
	

}
