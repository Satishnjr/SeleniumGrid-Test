package com.qa.tests;

import org.testng.annotations.Test;

public class LoginTest {
	
	
	@Test
	public void test1(){
		System.out.println("test1");
	}
	
	

}
